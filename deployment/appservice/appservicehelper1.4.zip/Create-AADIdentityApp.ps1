﻿# Copyright (c) Microsoft Corporation. All rights reserved.
# Create-AADIdentityApp.ps1

#requires -Version 4.0
#requires -RunAsAdministrator

[CmdletBinding()]
Param
(
    # The directory tenant identifier of the Azure Stack credential and subscription.
    [Parameter(Mandatory=$true, HelpMessage="Azure Active Directory Tenant Name, not GUID. Example: contoso.onmicrosoft.com")]
    [ValidateNotNull()]
    [string] $DirectoryTenantName,

    [Parameter(Mandatory=$true, HelpMessage="Admin resource manager endpoint. Example: adminmanagement.local.azurestack.external")]
    [string] $AdminArmEndpoint,

    [Parameter(Mandatory=$true, HelpMessage="Tenant resource manager endpoint. Example: management.local.azurestack.external")]
    [string] $TenantArmEndpoint,

    [Parameter(Mandatory=$true, HelpMessage="Path to the identity application's certificate PFX file.")]
    [ValidateNotNull()]
    [string] $CertificateFilePath,
        
    [Parameter(Mandatory=$true, HelpMessage="Password used to encrypt certificate PFX files.")]
    [ValidateNotNull()]
    [SecureString] $CertificatePassword,

    # The name of the supported Cloud Environment in which the target Graph Service is available.
    [ValidateSet('AzureCloud', 'AzureChinaCloud', 'AzureUSGovernment', 'AzureGermanCloud')]
    [string] $Environment = 'AzureCloud',

    # Allow delay initialization for MFA
    [Parameter(Mandatory=$false, HelpMessage="Azure Stack user credential with 'owner' permissions on the target Azure Stack Subscription. Scripts will prompts for credentials if not provided.")]
    [PSCredential] $AzureStackAdminCredential
)

$ErrorActionPreference = 'Stop'
$VerbosePreference = 'Continue'

 # Load common functions
 . "$PSScriptRoot\Common.ps1"

# Main
Import-Module $PSScriptRoot\Modules\GraphAPI.psm1 -Force

$scriptName = $MyInvocation.MyCommand.Name
$startTime = [System.DateTimeOffset]::Now
Write-Verbose -Message "Executing Script $scriptName at $startTime" -Verbose
Write-Verbose -Message "Using Parameters: " -Verbose
Write-Verbose -Message $($PSBoundParameters | ConvertTo-Json) -Verbose

$azEnvironment = Get-AzureStackEnvironment -DirectoryTenantName $DirectoryTenantName `
             -EnvironmentName "AzureStackAdmin" `
             -ArmEndpoint $AdminArmEndpoint `
             -Verbose

$DomainName = Get-AzureStackDomainName($AdminArmEndpoint);

$webAppsResourceProviderFqdn = "sso.appservice.$($DirectoryTenantName)".Trim('.').ToLowerInvariant()
Write-Verbose "Resource Provider FQDN resolved to: '$webAppsResourceProviderFqdn'" -Verbose

# extract the ARM resource and deployment identifier
$TenantArmResource = Get-ArmResourceId -ArmEndpoint $TenantArmEndpoint
Write-Verbose "ARM resource Uri: '$TenantArmResource'" -Verbose
$deploymentidentifier = $TenantArmResource.Split('/')[-1].ToLowerInvariant()

# Hack - if the deployment identifier is not a GUID, "cast" into something that serves a similair purpose of reliably identifying the environment
if (-not [GUID]::TryParse($deploymentidentifier, [ref][guid]@{}))
{
    Write-Warning "Deployment identifier initially resolved as non-guid value '$deploymentidentifier'; attempting to transform to guid-like value (hash)"
    $deploymentidentifier = $deploymentidentifier.GetHashCode().ToString('x8').ToLowerInvariant()
    Write-Verbose "Deployment identifier resolved to '$deploymentidentifier'"
}

Write-Output $deploymentidentifier

# ------------------------------------------
# Initialize Client Certificate

$identityCertificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(
                            $CertificateFilePath,
                            $CertificatePassword,
                            ([System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable -bor
                                [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet -bor
                                [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet))

# ------------------------------------------
# Initialize Identity Application

$refreshToken = Get-AzureRmUserRefreshToken -azureEnvironment $azEnvironment `
                    -directoryTenantId $DirectoryTenantName `
                    -AutomationCredential $AzureStackAdminCredential

Initialize-GraphEnvironment -DirectoryTenantId $DirectoryTenantName -RefreshToken $refreshToken -Environment $Environment | Out-Null

$identityApplicationInfoParams = 
@{
    DisplayName   = "App Service"
    Homepage      = "https://$webAppsResourceProviderFqdn"
    ReplyAddress  = @("https://appservice.sso.appservice.$($DomainName)/", "https://api.appservice.$($DomainName):44300/manage")
    IdentifierUri = "https://$webAppsResourceProviderFqdn/$deploymentidentifier".ToLower()

    # These permissions are what your application can do when it requests a token as itself, outside the context of a user request
    ApplicationAadPermissions = 
    @(
        'ReadDirectoryData'
    )

    # These permissions are what your application can do on behalf of a user in the context of a user request
    DelegatedAadPermissions = 
    @(
        'EnableSignOnAndReadUserProfiles',
        'ReadDirectoryData'
    )

    # This permission is required if you use the user's token to call ARM on the user's behalf (and will introduce a consent page when user logs-in for the first time)
    ResourceAccessByAppUris = @($TenantArmResource)

    # These tags go on the service principal, shown below is a standard tag we include with all Azure Stack AAD applications
    Tags = 
    @(
        ConvertTo-Json ([pscustomobject]@{AzureStackMetadata=[pscustomobject]@{CreationDate=[datetime]::UtcNow; DeploymentGuid=$deploymentIdentifier}}) -Compress
    )

    ClientCertificate = $identityCertificate
}

$app = Initialize-GraphApplication @identityApplicationInfoParams -Verbose
Write-Verbose -Message ($app | ConvertTo-Json) -Verbose
$sp = Get-GraphApplicationServicePrincipal -ApplicationId $app.appId
Write-Verbose -Message ($sp | ConvertTo-Json) -Verbose
$applicationId = $app.appId
$graphInfo = Get-GraphEnvironmentInfo
Write-Verbose -Message ($graphInfo  | ConvertTo-Json) -Verbose

Write-Host -ForegroundColor Green "Please note Application Id: $($applicationId)"
Write-Host -ForegroundColor Green "Sign in to the Azure portal as Azure Active Directory Service Admin -> Search for Application Id and grant permissions."

return $applicationId

# SIG # Begin signature block
# MIIhxwYJKoZIhvcNAQcCoIIhuDCCIbQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBwM0NIpH4/DzZq
# Pu8TBFEdiD/hiOCw2WL+8pOUwXrDxqCCCuEwggUCMIID6qADAgECAhMzAAABwxOg
# hcNW4pnXAAAAAAHDMA0GCSqGSIb3DQEBCwUAMIGEMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS4wLAYDVQQDEyVNaWNyb3NvZnQgV2luZG93cyBQ
# cm9kdWN0aW9uIFBDQSAyMDExMB4XDTE4MDcwMzIwNDU0OVoXDTE5MDcyNjIwNDU0
# OVowcDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEaMBgGA1UE
# AxMRTWljcm9zb2Z0IFdpbmRvd3MwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQCojxxN9SKuRbZ/yKvSKbbS0trHXj0+gPNH4fKzYIr/qfFnuANr1oUGtu08
# i5fqj3ZoICsiuQ7PXQ4XKF0bjGqQGug43UFYcIBV/ZBOYtgaNQotMHVTqxJZQUQU
# G0X6R1bu9YTQFkzmRBWfPlU+XrBFONgQ81tuZiRRF/8FR4utykOgIdQpD9HBIw1L
# oXsUOuMuRNInl/foq9g+4Dr8wpC50xcnvV1i3JS0dgx05H/jT/B1Tp+LP5aWJR0A
# vL6f7dhD6SoUCfRBbuSL8EfKMyMDb30GCKCi8I2StyTWY+dZLYXfHx8nbn9nRNoA
# Va2WwoiCobJ/o01rQWmm/J1PzOvjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgor
# BgEEAYI3CgMGBggrBgEFBQcDAzAdBgNVHQ4EFgQUe1BJOLY8GprYzjpFHQ86Fj1i
# rd4wUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25z
# IFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMjk4NzkrNDM3OTUzMB8GA1UdIwQYMBaA
# FKkpAjmOFsSXeM2Q+Z5PmuF8Va9TMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY1dpblByb1BDQTIwMTFfMjAx
# MS0xMC0xOS5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY1dpblByb1BDQTIwMTFf
# MjAxMS0xMC0xOS5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAQEA
# pc+Z5laZYW4G6AjEPWx+qR9HnQocetApxn1ewzMBwXQF5a5LmrJAmiDPZjAY7IAE
# upVutLSX4mnoE+NK3gASDtXbfmekgn/ieV/gslRxtGPEk+GMqxButzEkN1gwENsX
# XVxOEDjOS7XXzpoJQtNdDKCT71aFQbYi7SJ6tsKvPMDfpx7+LTQeKOANsFLBNnsm
# bR3FCi5GgPXFwESg42bhQS5T2wiZz+ncp9hu9gzH0cGZ4y4CAEDoL9yVoOL+TThP
# /PPuE276kYn6MZVcG95y3vPa+guPeRT1Eszee7/bP/xRxbh9Pta4Hf//Qhe8A3qM
# +Kpmge73FeJgGnFqSj0+nzCCBdcwggO/oAMCAQICCmEHdlYAAAAAAAgwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTExMTAxOTE4NDE0MloXDTI2MTAxOTE4NTE0MlowgYQxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLjAsBgNVBAMTJU1pY3Jvc29mdCBX
# aW5kb3dzIFByb2R1Y3Rpb24gUENBIDIwMTEwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDdDLui5C4J4+fF95ZpvAAhvWkzM++tBMtUgO4Gg7vFIITZ99KL
# 8ziwq6StLXxieQX/40o/BDUgcOPE52vgnMA2demKMd2NcOXcN7V0RpYoW4dgIyy/
# 3EelZ/dRJ55y6wemybkeO1M1fOXT7Ce5hxz+uckjCW+oRpHBbpY8QdPLoz9dAmpN
# 7GkfJShcNv/9QxUKlOAZtM/fwhLiwlsn7id4MItbKglrIolTYBYswGgdU7rsSfOd
# YYyFaAlzRF19olQr3Xn3Fc81XWwcK1zOvJwji29utSbZNhPDT9YnrrkyO0GSLOHH
# zXfoqlRO91wLBIdltEMYqLLgbRl37Fok+kgDAgMBAAGjggFDMIIBPzAQBgkrBgEE
# AYI3FQEEAwIBADAdBgNVHQ4EFgQUqSkCOY4WxJd4zZD5nk+a4XxVr1MwGQYJKwYB
# BAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBL
# oEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggr
# BgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBABT8fHFR
# pXnCbrLvOT68PFIPbis/EBNz/qho0EimNE2KlgUm7jFGkGF51v84LkVr9MDlKLja
# HY+K2wnXGsdMCjZmaozsG9cEkKgYF6SbueJAMjZ2xMFaxr/kBMDqFtOsw2jvYqzd
# VGxQMFim63z+lKdOjvTsfIZzV8JSIXM0WvOjilbIBNoHCe34i+PO9H6OrvD2C4oI
# +z/JHXJ/U7jrvmPg4z0xZbCB5fKszRaknz2osZvCQtCQhF9UHf+J6rodR5BvsHNO
# QZ9An1/loSqyEZFziiEo8M7eczlfPqtcYOzfAxCo0wnp9PaWhbZ/UYhmRxmNorAS
# PYEqaAV3u5FMYnu2wQfHunqHNAMOS2J6menK/M5KN8ktpFd8HP493LgPWvrWxLMC
# hQI66rPZbuRpITfegdH2dRkFZ9OTV14pGznI7i3hzeRFc1vQ0s56qxYZgkZY0F6d
# gbNnr2w18rzlPyTiNaIKdQb2GFaZ1Hgs0QUb69CIAZ2qEPEF37p+LGO3BpsjIcT5
# eGziWBcGNiuREgPMpNnyLbr5lJ1A7RhF8c6KXGs+qwPTcBgqCmrgX0fR1WMKMvKv
# 1zYfKnBa5UJZCHFLV7p+g4HwITz0HMHFuZCTDohFk4bpsSCZvpjLxZWkXWLWoGMI
# IL11EHd9PfNFuZ+Xn8tXgG8zqQTPd6RiHFl+MYIWPDCCFjgCAQEwgZwwgYQxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLjAsBgNVBAMTJU1pY3Jv
# c29mdCBXaW5kb3dzIFByb2R1Y3Rpb24gUENBIDIwMTECEzMAAAHDE6CFw1bimdcA
# AAAAAcMwDQYJYIZIAWUDBAIBBQCggcYwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# IIvsFd9tRy1Dq5T36xadb8JLa9TYnnLRWx8W86rTkaWEMFoGCisGAQQBgjcCAQwx
# TDBKoCSAIgBNAGkAYwByAG8AcwBvAGYAdAAgAFcAaQBuAGQAbwB3AHOhIoAgaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3dpbmRvd3MwDQYJKoZIhvcNAQEBBQAEggEA
# Qgb3mCtm9ZesLdcwmDySQeZ2rIzrtm8junxN67hFrE2x5lwglVlzGIcTZayG+57b
# 3fJyAlG/6njku/AYkmRtZKwuteph6a2dyeRFQjff+FeO0UCF8Y71CRA3QVlkXJNJ
# LaTgnJe3Kz5S5p1pwHOUttCbXndofeudBgZY/nH/3MiCSGyxUmGGdXxSlv4oiGOC
# z9XAA09aY6hiXI7DrPOOnB6fJO297+qgmfubsvvap6D4TA3SQhvyCm9tydnkuXyH
# onTK84nRpq4L4dS3vbgwuNee4wPmwrPDPqX9gMy9VB0P7+vVO00yfvoJquCQnO5B
# gCziH7fo6O4rBfFD/quKsaGCE6cwghOjBgorBgEEAYI3AwMBMYITkzCCE48GCSqG
# SIb3DQEHAqCCE4AwghN8AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFUBgsqhkiG9w0B
# CRABBKCCAUMEggE/MIIBOwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCAdoYcaS1ZI7vOlEI34Mv9Z5fb0XvlFPqIuG9Drh0dZwAIGW/xv9uxIGBMyMDE4
# MTEyOTA1NDU1NS4wNDZaMAcCAQGAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxMkU3LTMwNjQt
# NjExMjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDxMw
# ggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3Nv
# ZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2
# NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6
# f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458
# YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJY
# R4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9L
# ZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioK
# MfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8i
# TQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyK
# MZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjR
# PZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# bDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGg
# BgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBA
# BggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABh
# AHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4Fx
# Az2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcI
# K1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/
# HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QTh
# cJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXsh
# bcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXl
# ZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnf
# XXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvs
# xsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch
# 98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu
# 3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8J
# JxzVs341Hgi62jbb01+P3nSISRIwggTxMIID2aADAgECAhMzAAAA6uHO/5qzppLR
# AAAAAADqMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMB4XDTE4MDgyMzIwMjcxN1oXDTE5MTEyMzIwMjcxN1owgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjEyRTct
# MzA2NC02MTEyMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwX9+Ph5YsiemWsANC0pH
# dsugA/oSlr/Pvp6z8+ucpSbnIVMJBkhvlU7XZ3nucoBn3zrMnnq/OHMlQvVpgaEj
# oE+TP+GMX5tJAOsLnvNrjtARx0wU/Be3r5yqwvLA+xKgdnjFHZmISdkZZ4FYqqbb
# VhSnYYwcOa8Ibh3hHUGDud3mYttGuthmZxxxV4R5gUULItV5G362Y3mPRDj0d/EK
# dcAEA6Xlux5WGiUV2KYsRiO2weHMH4/G+T7ptDwxARZbgOtLwlClUnd4eoDOb8EP
# EokjU19LROhVENpx7qyTtlKLt/M629y0v33B6pvSzFmn2Fv/ndMPJ+MterNeByil
# 7QIDAQABo4IBGzCCARcwHQYDVR0OBBYEFNLHsBeuGb7tcIL7VOmkbbfHxaWuMB8G
# A1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeG
# RWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUH
# MAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3Rh
# UENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwDQYJKoZIhvcNAQELBQADggEBAKe7zRuaoAToWkVtxpB/VIY7owR7HHlY
# B/8fLS5Y0HjYjY8BkTlrL8x/RmZmF/xxPx1q91gZhG86ozluHZOKEDb1VcgXjo1v
# H/kdTKO+CT9+H5Fy5mAUB11wTFstcU4HJYXLRcjX6ykiE//jf2bRhETHiD62HKQZ
# mIewTuKZKBGSFZ6hNKY97YAof8ipHnQUO/xQT9OBtdaBTEJzSHvzLLFxlcReOAIg
# rpAsJFj1E3IicYSlSsC++Pe433VfWUkQjcHYH9W30/Z/LlFsawMmtnl+5wrZc5Kk
# ylJnz30NY/3l3EXhV8dXGyIMG4r+SEjES2qovFawennhINBbKi7+4sihggOlMIIC
# jQIBATCB+qGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046MTJFNy0zMDY0LTYxMTIxJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUAPGYS
# RVDZVqdRDp3O+LbqMQx4AFaggdowgdekgdQwgdExCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9w
# ZXJhdGlvbnMxJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjoyNjY1LTRDM0YtQzVE
# RTErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1hc3RlciBDbG9jazAN
# BgkqhkiG9w0BAQUFAAIFAN+piE8wIhgPMjAxODExMjgyMTM0MDdaGA8yMDE4MTEy
# OTIxMzQwN1owdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA36mITwIBADAHAgEAAgIY
# EDAHAgEAAgIZNTAKAgUA36rZzwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEE
# AYRZCgMBoAowCAIBAAIDFuNgoQowCAIBAAIDB6EgMA0GCSqGSIb3DQEBBQUAA4IB
# AQAEwWy/Tx4Il6Hb7frkdYXDCHMtGeiYjeP8UzWMoBICW8a4dQcsgTOk33mG2Jzn
# RZ7nRFVF62Lvu4lS8tQ53yQ86YS74Xj7PxCVaoVddfqwxxOlabN2b2AHy8TQqcBW
# PrbNRSvvADWuZQOhU6slJf0OcYTfHRS+0ofFLrMtZp22b9k46OsfhHdGv5nY4yjA
# RkkScrXE3TlQsRRj6UlF/qFHXWEQrH7C7tXwd5y1MDju66mc42ab+tX967P7xnRB
# ovRqU5euleT9aCbDqUeQ1fGYPKIsoTnnjfJ0a+qPUiZE+/KuptRxqnc6iZrIySAT
# D3SVFYvZrOnlKd0A+aGu2f/7MYIC9TCCAvECAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAADq4c7/mrOmktEAAAAAAOowDQYJYIZIAWUDBAIB
# BQCgggEyMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQg2L8S2W7IA+viGAnGKzopbuk1tpvF5U0DSGy534/Ak1EwgeIGCyqGSIb3DQEJ
# EAIMMYHSMIHPMIHMMIGxBBQ8ZhJFUNlWp1EOnc74tuoxDHgAVjCBmDCBgKR+MHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA6uHO/5qzppLRAAAAAADq
# MBYEFFhJLOV1+Mg+Wrl00CkpXr1lZ+T9MA0GCSqGSIb3DQEBCwUABIIBALjS/LtU
# z6kBrvJGH0vQG/hU7B7OG0khY/3u7csPHk6ofUN6R3bFW8PIGaUHIImfcCqD2d1j
# /nmTvKXefyKM5erjcQcA5WaiBrpeQBEQmjihScmY9pt30xpSOOKjXoUBK6Nq/Mk8
# QTj5uQIIs4CERdl+K4ZcKl83Po9t/aS0YK73ezbx4X+F11lespAz0ytezdx0Wo27
# wXtboSH8chiNYYbSd0gswWyjWiHIeY5YvG+7q1MsQjBmIDwmW+n1kd0X5KmZdOau
# tOlugWKGPiYGa9cnel8Dx0nf58C/6XV7ae8IHpxJIpJb802BgW9za2ywr9m1NBKa
# mF65Sjtpge+DFhw=
# SIG # End signature block
