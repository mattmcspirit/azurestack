﻿# Copyright (c) Microsoft Corporation. All rights reserved.
# Create-ADFSIdentityApp.ps1

#requires -Version 4.0
#requires -RunAsAdministrator

[CmdletBinding()]
Param
(
    [Parameter(Mandatory=$true, HelpMessage="Admin resource manager endpoint. Example: adminmanagement.local.azurestack.external")]
    [string] $AdminArmEndpoint,

    [Parameter(Mandatory=$true, HelpMessage="Emergency console privileged endpoint. Example: AzS-ERCS01")]
    [string] $PrivilegedEndpoint,

    [Parameter(Mandatory=$true, HelpMessage="Azure Stack cloudadmin domain account credential. e.g. AZURESTACK\CloudAdmin")]
    [PSCredential] $CloudAdminCredential,

    [Parameter(Mandatory=$true, HelpMessage="Path to the identity application's certificate PFX file.")]
    [ValidateNotNull()]
    [string] $CertificateFilePath,

    [Parameter(Mandatory=$true, HelpMessage="Password used to encrypt certificate PFX files.")]
    [ValidateNotNull()]
    [SecureString] $CertificatePassword
)
 
# Main

$ErrorActionPreference = 'Stop'
$VerbosePreference = 'Continue'

# Load common functions
 . "$PSScriptRoot\Common.ps1"

$scriptName = $MyInvocation.MyCommand.Name
$startTime = [System.DateTimeOffset]::Now
Write-Verbose -Message "Executing Script $scriptName at $startTime" -Verbose
Write-Verbose -Message "Using Parameters: " -Verbose
Write-Verbose -Message $($PSBoundParameters | ConvertTo-Json) -Verbose

$DomainName = Get-AzureStackDomainName($AdminArmEndpoint);

$redirectUris=@( "https://localhost", `
                 "https://appservice.sso.appservice.$($DomainName)/",`
                 "https://api.appservice.$($DomainName):44300/manage" )

# ------------------------------------------
# Initialize Client Certificate

$identityCertificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(
                            $CertificateFilePath,
                            $CertificatePassword,
                            ([System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable -bor
                            [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet -bor
                            [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet))

# ------------------------------------------
# Initialize Identity Application


# Execute on Privileged Endpoint to create an ADFS app. Running it on other machines will fail due to JEA restrictions.
$session = New-PSSession -ComputerName $PrivilegedEndpoint `
               -ConfigurationName PrivilegedEndpoint `
               -Credential $CloudAdminCredential

$application = Invoke-Command -Session $session `
                        -ScriptBlock `
                        { 
                            New-GraphApplication -Name 'AppService' `
                                -ClientCertificates $using:identityCertificate `
                                -ClientRedirectUris $using:redirectUris
                        }

Remove-PSSession -Session $session

$appId = $application.ClientId

Write-Host -ForegroundColor Green "Please note Application Id: $($appId)"

return $appId

# SIG # Begin signature block
# MIIhxgYJKoZIhvcNAQcCoIIhtzCCIbMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAOTpJiPT8G//Sg
# 2nMyHkxu2PLHkfsygP4ijr2E3VNL7aCCCuEwggUCMIID6qADAgECAhMzAAABwxOg
# hcNW4pnXAAAAAAHDMA0GCSqGSIb3DQEBCwUAMIGEMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS4wLAYDVQQDEyVNaWNyb3NvZnQgV2luZG93cyBQ
# cm9kdWN0aW9uIFBDQSAyMDExMB4XDTE4MDcwMzIwNDU0OVoXDTE5MDcyNjIwNDU0
# OVowcDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEaMBgGA1UE
# AxMRTWljcm9zb2Z0IFdpbmRvd3MwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQCojxxN9SKuRbZ/yKvSKbbS0trHXj0+gPNH4fKzYIr/qfFnuANr1oUGtu08
# i5fqj3ZoICsiuQ7PXQ4XKF0bjGqQGug43UFYcIBV/ZBOYtgaNQotMHVTqxJZQUQU
# G0X6R1bu9YTQFkzmRBWfPlU+XrBFONgQ81tuZiRRF/8FR4utykOgIdQpD9HBIw1L
# oXsUOuMuRNInl/foq9g+4Dr8wpC50xcnvV1i3JS0dgx05H/jT/B1Tp+LP5aWJR0A
# vL6f7dhD6SoUCfRBbuSL8EfKMyMDb30GCKCi8I2StyTWY+dZLYXfHx8nbn9nRNoA
# Va2WwoiCobJ/o01rQWmm/J1PzOvjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgor
# BgEEAYI3CgMGBggrBgEFBQcDAzAdBgNVHQ4EFgQUe1BJOLY8GprYzjpFHQ86Fj1i
# rd4wUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25z
# IFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMjk4NzkrNDM3OTUzMB8GA1UdIwQYMBaA
# FKkpAjmOFsSXeM2Q+Z5PmuF8Va9TMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY1dpblByb1BDQTIwMTFfMjAx
# MS0xMC0xOS5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY1dpblByb1BDQTIwMTFf
# MjAxMS0xMC0xOS5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAQEA
# pc+Z5laZYW4G6AjEPWx+qR9HnQocetApxn1ewzMBwXQF5a5LmrJAmiDPZjAY7IAE
# upVutLSX4mnoE+NK3gASDtXbfmekgn/ieV/gslRxtGPEk+GMqxButzEkN1gwENsX
# XVxOEDjOS7XXzpoJQtNdDKCT71aFQbYi7SJ6tsKvPMDfpx7+LTQeKOANsFLBNnsm
# bR3FCi5GgPXFwESg42bhQS5T2wiZz+ncp9hu9gzH0cGZ4y4CAEDoL9yVoOL+TThP
# /PPuE276kYn6MZVcG95y3vPa+guPeRT1Eszee7/bP/xRxbh9Pta4Hf//Qhe8A3qM
# +Kpmge73FeJgGnFqSj0+nzCCBdcwggO/oAMCAQICCmEHdlYAAAAAAAgwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTExMTAxOTE4NDE0MloXDTI2MTAxOTE4NTE0MlowgYQxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLjAsBgNVBAMTJU1pY3Jvc29mdCBX
# aW5kb3dzIFByb2R1Y3Rpb24gUENBIDIwMTEwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDdDLui5C4J4+fF95ZpvAAhvWkzM++tBMtUgO4Gg7vFIITZ99KL
# 8ziwq6StLXxieQX/40o/BDUgcOPE52vgnMA2demKMd2NcOXcN7V0RpYoW4dgIyy/
# 3EelZ/dRJ55y6wemybkeO1M1fOXT7Ce5hxz+uckjCW+oRpHBbpY8QdPLoz9dAmpN
# 7GkfJShcNv/9QxUKlOAZtM/fwhLiwlsn7id4MItbKglrIolTYBYswGgdU7rsSfOd
# YYyFaAlzRF19olQr3Xn3Fc81XWwcK1zOvJwji29utSbZNhPDT9YnrrkyO0GSLOHH
# zXfoqlRO91wLBIdltEMYqLLgbRl37Fok+kgDAgMBAAGjggFDMIIBPzAQBgkrBgEE
# AYI3FQEEAwIBADAdBgNVHQ4EFgQUqSkCOY4WxJd4zZD5nk+a4XxVr1MwGQYJKwYB
# BAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBL
# oEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggr
# BgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBABT8fHFR
# pXnCbrLvOT68PFIPbis/EBNz/qho0EimNE2KlgUm7jFGkGF51v84LkVr9MDlKLja
# HY+K2wnXGsdMCjZmaozsG9cEkKgYF6SbueJAMjZ2xMFaxr/kBMDqFtOsw2jvYqzd
# VGxQMFim63z+lKdOjvTsfIZzV8JSIXM0WvOjilbIBNoHCe34i+PO9H6OrvD2C4oI
# +z/JHXJ/U7jrvmPg4z0xZbCB5fKszRaknz2osZvCQtCQhF9UHf+J6rodR5BvsHNO
# QZ9An1/loSqyEZFziiEo8M7eczlfPqtcYOzfAxCo0wnp9PaWhbZ/UYhmRxmNorAS
# PYEqaAV3u5FMYnu2wQfHunqHNAMOS2J6menK/M5KN8ktpFd8HP493LgPWvrWxLMC
# hQI66rPZbuRpITfegdH2dRkFZ9OTV14pGznI7i3hzeRFc1vQ0s56qxYZgkZY0F6d
# gbNnr2w18rzlPyTiNaIKdQb2GFaZ1Hgs0QUb69CIAZ2qEPEF37p+LGO3BpsjIcT5
# eGziWBcGNiuREgPMpNnyLbr5lJ1A7RhF8c6KXGs+qwPTcBgqCmrgX0fR1WMKMvKv
# 1zYfKnBa5UJZCHFLV7p+g4HwITz0HMHFuZCTDohFk4bpsSCZvpjLxZWkXWLWoGMI
# IL11EHd9PfNFuZ+Xn8tXgG8zqQTPd6RiHFl+MYIWOzCCFjcCAQEwgZwwgYQxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLjAsBgNVBAMTJU1pY3Jv
# c29mdCBXaW5kb3dzIFByb2R1Y3Rpb24gUENBIDIwMTECEzMAAAHDE6CFw1bimdcA
# AAAAAcMwDQYJYIZIAWUDBAIBBQCggcYwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# IBOu+akcypj/12k1YGqhmejrjyp52Lvp73h1QcxelN6AMFoGCisGAQQBgjcCAQwx
# TDBKoCSAIgBNAGkAYwByAG8AcwBvAGYAdAAgAFcAaQBuAGQAbwB3AHOhIoAgaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3dpbmRvd3MwDQYJKoZIhvcNAQEBBQAEggEA
# o9JSEiAEw9uRS8+SzgMF7vJ9HeF7pT3WXQ7ZUUDIq1dnQHHZEbsfPD3BUofxddYE
# 0hBjbvS6GS0Hj65U7ciL5hdepZQO/fHjRONYm+Ht204Q5hhdNdLelt6e8OzSMn+d
# qfkPQHkcheMpM+E8Z59cGcaItQhzSAOofsMa7HKiZqrJ78mGMu3YQClyOoE2vP9r
# pyOOHcAjlo4rT41B0c1nKWQ0yqlT1IJCcU7D5gShsjDJZWBAGITgEQUenkya3Z3H
# 3pzpTtNBpjoyKc18uDLd8IveY6mToxhHI9fKXRVCLyo0DdfPJy6vds8mdNivWW5F
# vpxzPZeyVfmsBE21EqA7FKGCE6YwghOiBgorBgEEAYI3AwMBMYITkjCCE44GCSqG
# SIb3DQEHAqCCE38wghN7AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFUBgsqhkiG9w0B
# CRABBKCCAUMEggE/MIIBOwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCDPqnDpMmV4FI5L6tZLP6n4juZaYig/mZHRW0RdON8WLgIGW/xv5OKvGBMyMDE4
# MTEyOTA1NDU1NC41OTJaMAcCAQGAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpDM0IwLTBGNkEt
# NDExMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDxIw
# ggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3Nv
# ZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2
# NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6
# f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458
# YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJY
# R4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9L
# ZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioK
# MfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8i
# TQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyK
# MZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjR
# PZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# bDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGg
# BgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBA
# BggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABh
# AHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4Fx
# Az2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcI
# K1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/
# HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QTh
# cJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXsh
# bcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXl
# ZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnf
# XXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvs
# xsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch
# 98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu
# 3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8J
# JxzVs341Hgi62jbb01+P3nSISRIwggTxMIID2aADAgECAhMzAAAAyCQZy6pU5mwq
# AAAAAADIMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMB4XDTE4MDgyMzIwMjYxM1oXDTE5MTEyMzIwMjYxM1owgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkMzQjAt
# MEY2QS00MTExMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA44mGILYaJ4ThEuFwA78Z
# mH2oQSIy8wqnqQJ5ic7nvGK7gQKjxv4bPrRifeFjzps3E2TG62FTBWst38CAl/s9
# ZozfsFt3/Crv5hHOHVbHkVYrBH3jr/xi9JXLVm9Ub6LDTEB7l9F4mj4q8HIVAs2Y
# P1h7x1TZwlbdXmdNHzF5EfmF+y6KeeAvskT89W0y1qTyJ0RRYsGD3uKqAlF+aYbZ
# 7HOUsGFMr7H/MtYcYMLDyTLq5QPpjEFJ+27yqGyvyfj7m/dhbV7IaYdAW6wZQNjj
# MWnPk77xxFjLpgihGuWMK14vvyCBAzzumLFPO5+KC2RpfYMNV+iNRKV998jsa1Zw
# pwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFP4w0enyVikOI9BFM3UMpZ7CUkDAMB8G
# A1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeG
# RWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUH
# MAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3Rh
# UENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwDQYJKoZIhvcNAQELBQADggEBAJOaM61oDQ2og12OxdrFda7V5H2NkJRu
# xSPqVpMHgz11e4RGX+iHYXRExePOni94SaZzSGF3mbjfrtlUULHqvgyYWVT17dRS
# btJqoGZnJcUPbo5MhosHij/ogKobX8YKOSprcSwjdIB5MFPUXZyO/IC8RaRt0ksc
# +GjOnX+FYU8RL789SmlLMjiXc2eNqzJ2YnaNkKg0O5syPla2HxLceAZuNQYB5zUM
# svRTtWQuxrGRd5IGuraPDnwHtU1rxLj+aCwmmrPLJOWXulzMxLgZMrNxZdNrDg+Y
# RBdeepWhPMT68IY4ql5G/oqkN2lFxCt/tZEfDAMkBJ4ICySs+A55NzOhggOkMIIC
# jAIBATCB+qGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046QzNCMC0wRjZBLTQxMTExJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUANJcm
# caPsEmrOgrfryoIY7WPSXU2ggdowgdekgdQwgdExCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9w
# ZXJhdGlvbnMxJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjoyNjY1LTRDM0YtQzVE
# RTErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1hc3RlciBDbG9jazAN
# BgkqhkiG9w0BAQUFAAIFAN+o4WgwIhgPMjAxODExMjgwOTQyMDBaGA8yMDE4MTEy
# OTA5NDIwMFowczA5BgorBgEEAYRZCgQBMSswKTAKAgUA36jhaAIBADAGAgEAAgEA
# MAcCAQACAhZbMAoCBQDfqjLoAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQB
# hFkKAwGgCjAIAgEAAgMW42ChCjAIAgEAAgMehIAwDQYJKoZIhvcNAQEFBQADggEB
# ALHH6YW99O1w62FoHAe1rnnvbY9qtZT40fg5bfQpQO/orhOedjUDQkIwb3kleLb4
# N8UHIRPVcG1adbMTB7fxIKuknKwgF3EnqTJfIFhaN0S1ZIB78a3L3D8tWDBSBPRC
# IrO83W6BvUd5iU4R+Ev7lAAToPtpsHxwjhlfg+GVzjAuU3JCjpaHwG4gfmHLwfGG
# 7Q5jutdA+99A0to7h15jcnCUQvrZopT1N8K79z7YkpDAsR8R+Ieo/bNLnWV8CTCs
# sumQSDMncAkSVnnf7m8vqvLeWafhYmiyKskNrFZYGwzUhzdWDNrWF/GgmAC7Ns9m
# d3HK5Dm0Jcx+eIDcJvPxrNoxggL1MIIC8QIBATCBkzB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMAITMwAAAMgkGcuqVOZsKgAAAAAAyDANBglghkgBZQMEAgEF
# AKCCATIwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEi
# BCAMroOaAo297ov7EXc1FgLFxBbTBNsjGLkjPfoZz+ETxjCB4gYLKoZIhvcNAQkQ
# AgwxgdIwgc8wgcwwgbEEFDSXJnGj7BJqzoK368qCGO1j0l1NMIGYMIGApH4wfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAADIJBnLqlTmbCoAAAAAAMgw
# FgQUMW1PCHZDs73kXNWyML/de2YXO/IwDQYJKoZIhvcNAQELBQAEggEAgDAkdVq2
# gQoFDkK7etfqKLyzIx3uDgM0iWhjtlB2tsXKlFAxUHHxMJBk+TtrxoRNyHt5A9JO
# kyxgGPJk+okXmu5imeiG1lroy7KtzNm0ZbMsu9GG1/C17pl9yXPbMl6wg4qtgXV9
# WwvRSePGZlB3Il0Cb0mWyJ4xFjZSuMo6cIvyCpJi9JoxAE56GPWJNkMGg/C+hS97
# MnQNiVHtHfbgxhs9dK+IXTJa+qnbUhoP6P+QeYgQslZrRMSCpB0BC36C6Fv5OZfp
# MjoOUUY56M5JxzGEihM1P2o9FdbXe+G+C49ItIjIDRnSya/ll8kOOKg+qSzC42Jc
# eDo6KKh+6aH/xA==
# SIG # End signature block
