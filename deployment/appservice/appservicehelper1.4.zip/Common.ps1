# Copyright (c) Microsoft Corporation. All rights reserved.
# Common.ps1

#requires -Version 4.0
#requires -RunAsAdministrator

# This function is copied from AzureStack.Identity.psm1
function Get-AzureRmUserRefreshToken([Microsoft.Azure.Commands.Profile.Models.PSAzureEnvironment]$azureEnvironment, [string]$directoryTenantId, [pscredential]$AutomationCredential)
{
    $params = 
    @{
        EnvironmentName = $azureEnvironment.Name
        TenantId        = $directoryTenantId
    }

    if ($AutomationCredential)
    {
        $params += @{ Credential = $AutomationCredential }
    }

    # Prompts the user for interactive login flow if automation credential is not specified
    $azureAccount = Add-AzureRmAccount @params

    try
    {
        # Works on Azure Stack Powershell >= 1.2.11
        $tokens = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.TokenCache.ReadItems()
    }
    catch
    {
        # Works on Azure Stack Powershell <= 1.2.10 (for backward compatibility)
        $tokens = [Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache]::DefaultShared.ReadItems()
    }

    # There can be multiple refresh tokens, but at most one will be valid (i.e. not expired). Sort by expiry time and use the latest one we have available.
    # Retrieve the refresh token
    $refreshToken = $tokens |
        Where Resource -EQ $azureEnvironment.ActiveDirectoryServiceEndpointResourceId |
        Where IsMultipleResourceRefreshToken -EQ $true |
        Where DisplayableId -EQ $azureAccount.Context.Account.Id |
        Sort ExpiresOn |
        Select -Last 1 -ExpandProperty RefreshToken |
        ConvertTo-SecureString -AsPlainText -Force

    return $refreshToken
}

function Get-AzsDirectoryTenantId ()
{
    [CmdletBinding(DefaultParameterSetName = 'AzureActiveDirectory')]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = 'ADFS')]
        [switch] $ADFS,

        [parameter(mandatory = $true, ParameterSetName = 'AzureActiveDirectory', HelpMessage = "AAD Directory Tenant <myaadtenant.onmicrosoft.com>")]
        [string] $AADTenantName,

        [Parameter(Mandatory = $true, ParameterSetName = 'ADFS')]

        [Parameter(Mandatory = $true, ParameterSetName = 'AzureActiveDirectory')]
        [string] $EnvironmentName
    )
    
    $AzEnvironment = Get-AzureRmEnvironment -Name $EnvironmentName
    $ADauth = $AzEnvironment.ActiveDirectoryAuthority
    if ($ADFS -eq $true) 
    {
        if (-not (Get-AzureRmEnvironment -Name $EnvironmentName).EnableAdfsAuthentication)
        {
            Write-Error "This environment is not configured to do ADFS authentication." -ErrorAction Stop
        }

        return $(Invoke-RestMethod $("{0}/.well-known/openid-configuration" -f $ADauth.TrimEnd('/'))).issuer.TrimEnd('/').Split('/')[-1]
    }
    else 
    {
        $endpt = "{0}{1}/.well-known/openid-configuration" -f $ADauth, $AADTenantName
        $OauthMetadata = (Invoke-WebRequest -UseBasicParsing $endpt).Content | ConvertFrom-Json
        $AADid = $OauthMetadata.Issuer.Split('/')[3]

        return $AADid
    }
}

function Add-AzureStackAccount
{
    Param
    (
        [Parameter(Mandatory=$true, HelpMessage="Azure stack environment Name")]
        [string] $AzEnvironmentName,

        [Parameter(Mandatory=$true, HelpMessage="Tenant Directory ID")]
        [string] $DirectoryId,

        # The Azure Stack credential with "owner" permissions on the target Azure Stack Subscription.
        # The scripts prompts for the username and password if the AzureStackCredential parameter is not set.
        [Parameter(Mandatory=$false, HelpMessage="The Azure Stack credential with owner permissions on the target Azure Stack Subscription")]
        [System.Management.Automation.PSCredential] $AzureStackCredential   
    )
    
    try
    {
      $context = Get-AzureRmContext -ErrorAction SilentlyContinue
    }
    catch
    {
        # the cmdlet still report error with SilentlyContinue, so use try and catch here.
    }

    if ($AzureStackCredential)
    {
        $azAccount = Add-AzureRmAccount -EnvironmentName $AzEnvironmentName -Credential $AzureStackCredential -TenantId $DirectoryId
    }
    else
    {
        $azAccount = Add-AzureRmAccount -EnvironmentName $AzEnvironmentName -TenantId $DirectoryId
    }

    if(-not $azAccount)
    {
        throw "Could not login in"
    }
    else
    {
        Write-Verbose "Login successful"
    }

    return $azAccount
}

function Get-AzureStackEnvironment
{
    Param
    (
        [Parameter(Mandatory=$true, HelpMessage="Tenant Directory ID")]
        [string] $DirectoryTenantName,

        [Parameter(Mandatory=$false, HelpMessage="Friendly name of Azure stack")]
        [string] $EnvironmentName = "AzureStack",

        [Parameter(Mandatory=$true, HelpMessage="Azurestack Admin Arm Endpoint")]
        [string] $ArmEndpoint
    )

    $azEnvironment = Get-AzureRmEnvironment $EnvironmentName -ErrorAction SilentlyContinue
    if($azEnvironment -ne $null)
    {
       Remove-AzureRmEnvironment -Name $EnvironmentName | Out-Null
    }

    $armEndpoint = $ArmEndpoint;

    $metadataUri= "https://$armEndpoint/metadata/endpoints?api-version=1.0"

    $endpoints = Invoke-RestMethod -Uri $metadataUri
    $authorityEndpoint = $endpoints.authentication.loginEndpoint

    $azEnvironment = Add-AzureRmEnvironment `
        -Name $EnvironmentName `
        -ArmEndpoint "https://$armEndpoint"
        
    $azEnvironment = Get-AzureRmEnvironment $EnvironmentName

    return $azEnvironment
}

function Initialize-AzureStackEnvironment
{
    Param
    (
        [Parameter(Mandatory=$true, HelpMessage="Tenant Directory Name")]
        [string] $DirectoryTenantName,

        [Parameter(Mandatory=$true, HelpMessage="Friendly name of Azure stack")]
        [string] $EnvironmentName = "AzureStack",
         
        [Parameter(Mandatory=$true, HelpMessage="Azurestack Admin Arm Endpoint")]
        [string] $ArmEndpoint,

        [Parameter(Mandatory=$false, HelpMessage="Credential object of Azure Stack")]
        [PSCredential] $AzureStackCredential
    )

    $DomainName = Get-AzureStackDomainName($ArmEndpoint);

    $azEnvironment = Get-AzureStackEnvironment -DirectoryTenantName $DirectoryTenantName -EnvironmentName $EnvironmentName -ArmEndpoint $ArmEndpoint

    if ($azEnvironment.EnableAdfsAuthentication)
    {
        # Get the Active Directory tenantId that is used to deploy Azure Stack
        $directoryTenantId = Get-AzsDirectoryTenantId `
          -ADFS `
          -EnvironmentName $EnvironmentName
    }
    else
    {   
        # Get the Active Directory tenantId that is used to deploy Azure Stack
        $directoryTenantId =  Get-AzsDirectoryTenantId `
            -AADTenantName $DirectoryTenantName `
            -EnvironmentName $EnvironmentName
    }
    
    $azAccount = Add-AzureStackAccount -AzureStackCredential $AzureStackCredential -AzEnvironmentName $EnvironmentName -DirectoryId $directoryTenantId

    return $azAccount
}

function Get-ArmResourceId([string] $ArmEndpoint)
{
    $metadataUri= "https://{0}/metadata/endpoints?api-version=1.0" -f $ArmEndpoint
    $metadata = Invoke-RestMethod -Uri $metadataUri

    return $metadata.authentication.audiences[0]
}

function Get-AzureStackDomainName
{
    Param
    (
        [Parameter(Mandatory=$true, HelpMessage="Azurestack ArmEndpoint")]
        [string] $ArmEndpoint
    )

    $trimmed = ($ArmEndpoint.Trim("/").Split(".") | select -Skip 1) -join "."
    $DomainName = $trimmed.Split(":")[0]

    return $DomainName
}

function Get-AzureStackStampInfo
{
    Param
    (
        [Parameter(Mandatory=$true, HelpMessage="Emergency console privileged endpoint. Example: AzS-ERCS01")]
        [string] $PrivilegedEndpoint,

        [Parameter(Mandatory=$true, HelpMessage="Azure Stack cloudadmin domain account credential. e.g. AZURESTACK\CloudAdmin")]
        [PSCredential] $CloudAdminCredential
    )

    try
    {
        # set the emergency console to the trusted host.
        $currentTrustedRoot = (Get-Item WSMan:\localhost\Client\TrustedHosts).Value
        if([string]::IsNullOrEmpty($currentTrustedRoot) -or (-not $currentTrustedRoot.Contains($PrivilegedEndpoint)))
        {
            $allowAllHost = $false;
            foreach($trustHost in $currentTrustedRoot.Split(","))
            {
                if($trustHost -eq "*")
                {
                    $allowAllHost = $true;
                    break;
                }
            }

            if(-not $allowAllHost)
            {
                Set-Item wsman:\localhost\Client\TrustedHosts -Value "$currentTrustedRoot, $PrivilegedEndpoint" -Force
            }
        }

        $domainAdminSession = New-PSSession -ComputerName $PrivilegedEndpoint -Credential $CloudAdminCredential -configurationname privilegedendpoint -Verbose
        $stampInfo = Invoke-Command -Session $domainAdminSession -Verbose -ErrorAction Stop -ScriptBlock { Get-AzureStackStampInformation }

        return $stampInfo
    }
    finally
    {
        if ($domainAdminSession -ne $null)
        {
            Remove-PSSession $domainAdminSession -Verbose
        }
    }
}

function Get-AzureStackRootCertificateThumbprint
{
    Param
    (
        [Parameter(Mandatory=$true, HelpMessage="Azure Stack Resource Manager root url (either Admin or Tenant), e.g. https://adminmanagement.local.azurestack.external/")]
        $ARMUrl
    )

    $metaResponse = Invoke-WebRequest -UseBasicParsing "$($ARMUrl)metadata/authentication?api-version=2015-01-01"
    $authenticationJson = ConvertFrom-Json $metaResponse.Content
    $rootThumb = $null
    
    $authenticationJson.clientCertificates.certificate | Foreach `
    {
        $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]([System.Convert]::FromBase64String($_))
    
        $chain = New-Object System.Security.Cryptography.X509Certificates.X509Chain
        $chain.ChainPolicy.RevocationMode = [System.Security.Cryptography.X509Certificates.X509RevocationMode]::NoCheck
        
        if ($chain.Build($cert))
        {
            if ($chain.ChainElements.Count -gt 1)
            {
                if ($rootThumb)
                {
                    if ($chain.ChainElements[$chain.ChainElements.Count-1].Certificate.Thumbprint -ne $rootThumb)
                    {
                        throw "Multile root certificates found!"
                    }
                }
                
                $rootThumb = $chain.ChainElements[$chain.ChainElements.Count-1].Certificate.Thumbprint
            }
            else
            {
                throw "Incorrect certificate chain"
            }
        }
        else
        {
            throw "Certificate chain broken"
        }
    }

    if (!$rootThumb) 
    {
        throw "No active root certificate is found"
    }

    return $rootThumb
}
# SIG # Begin signature block
# MIIhxwYJKoZIhvcNAQcCoIIhuDCCIbQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQ7wZ36rHmEvV6
# OnYGEd+/bdXLKIYkzfGhB3rciQvkJqCCCuEwggUCMIID6qADAgECAhMzAAABwxOg
# hcNW4pnXAAAAAAHDMA0GCSqGSIb3DQEBCwUAMIGEMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS4wLAYDVQQDEyVNaWNyb3NvZnQgV2luZG93cyBQ
# cm9kdWN0aW9uIFBDQSAyMDExMB4XDTE4MDcwMzIwNDU0OVoXDTE5MDcyNjIwNDU0
# OVowcDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEaMBgGA1UE
# AxMRTWljcm9zb2Z0IFdpbmRvd3MwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQCojxxN9SKuRbZ/yKvSKbbS0trHXj0+gPNH4fKzYIr/qfFnuANr1oUGtu08
# i5fqj3ZoICsiuQ7PXQ4XKF0bjGqQGug43UFYcIBV/ZBOYtgaNQotMHVTqxJZQUQU
# G0X6R1bu9YTQFkzmRBWfPlU+XrBFONgQ81tuZiRRF/8FR4utykOgIdQpD9HBIw1L
# oXsUOuMuRNInl/foq9g+4Dr8wpC50xcnvV1i3JS0dgx05H/jT/B1Tp+LP5aWJR0A
# vL6f7dhD6SoUCfRBbuSL8EfKMyMDb30GCKCi8I2StyTWY+dZLYXfHx8nbn9nRNoA
# Va2WwoiCobJ/o01rQWmm/J1PzOvjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgor
# BgEEAYI3CgMGBggrBgEFBQcDAzAdBgNVHQ4EFgQUe1BJOLY8GprYzjpFHQ86Fj1i
# rd4wUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25z
# IFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMjk4NzkrNDM3OTUzMB8GA1UdIwQYMBaA
# FKkpAjmOFsSXeM2Q+Z5PmuF8Va9TMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY1dpblByb1BDQTIwMTFfMjAx
# MS0xMC0xOS5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY1dpblByb1BDQTIwMTFf
# MjAxMS0xMC0xOS5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAQEA
# pc+Z5laZYW4G6AjEPWx+qR9HnQocetApxn1ewzMBwXQF5a5LmrJAmiDPZjAY7IAE
# upVutLSX4mnoE+NK3gASDtXbfmekgn/ieV/gslRxtGPEk+GMqxButzEkN1gwENsX
# XVxOEDjOS7XXzpoJQtNdDKCT71aFQbYi7SJ6tsKvPMDfpx7+LTQeKOANsFLBNnsm
# bR3FCi5GgPXFwESg42bhQS5T2wiZz+ncp9hu9gzH0cGZ4y4CAEDoL9yVoOL+TThP
# /PPuE276kYn6MZVcG95y3vPa+guPeRT1Eszee7/bP/xRxbh9Pta4Hf//Qhe8A3qM
# +Kpmge73FeJgGnFqSj0+nzCCBdcwggO/oAMCAQICCmEHdlYAAAAAAAgwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTExMTAxOTE4NDE0MloXDTI2MTAxOTE4NTE0MlowgYQxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLjAsBgNVBAMTJU1pY3Jvc29mdCBX
# aW5kb3dzIFByb2R1Y3Rpb24gUENBIDIwMTEwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDdDLui5C4J4+fF95ZpvAAhvWkzM++tBMtUgO4Gg7vFIITZ99KL
# 8ziwq6StLXxieQX/40o/BDUgcOPE52vgnMA2demKMd2NcOXcN7V0RpYoW4dgIyy/
# 3EelZ/dRJ55y6wemybkeO1M1fOXT7Ce5hxz+uckjCW+oRpHBbpY8QdPLoz9dAmpN
# 7GkfJShcNv/9QxUKlOAZtM/fwhLiwlsn7id4MItbKglrIolTYBYswGgdU7rsSfOd
# YYyFaAlzRF19olQr3Xn3Fc81XWwcK1zOvJwji29utSbZNhPDT9YnrrkyO0GSLOHH
# zXfoqlRO91wLBIdltEMYqLLgbRl37Fok+kgDAgMBAAGjggFDMIIBPzAQBgkrBgEE
# AYI3FQEEAwIBADAdBgNVHQ4EFgQUqSkCOY4WxJd4zZD5nk+a4XxVr1MwGQYJKwYB
# BAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMB
# Af8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBL
# oEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMv
# TWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggr
# BgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBABT8fHFR
# pXnCbrLvOT68PFIPbis/EBNz/qho0EimNE2KlgUm7jFGkGF51v84LkVr9MDlKLja
# HY+K2wnXGsdMCjZmaozsG9cEkKgYF6SbueJAMjZ2xMFaxr/kBMDqFtOsw2jvYqzd
# VGxQMFim63z+lKdOjvTsfIZzV8JSIXM0WvOjilbIBNoHCe34i+PO9H6OrvD2C4oI
# +z/JHXJ/U7jrvmPg4z0xZbCB5fKszRaknz2osZvCQtCQhF9UHf+J6rodR5BvsHNO
# QZ9An1/loSqyEZFziiEo8M7eczlfPqtcYOzfAxCo0wnp9PaWhbZ/UYhmRxmNorAS
# PYEqaAV3u5FMYnu2wQfHunqHNAMOS2J6menK/M5KN8ktpFd8HP493LgPWvrWxLMC
# hQI66rPZbuRpITfegdH2dRkFZ9OTV14pGznI7i3hzeRFc1vQ0s56qxYZgkZY0F6d
# gbNnr2w18rzlPyTiNaIKdQb2GFaZ1Hgs0QUb69CIAZ2qEPEF37p+LGO3BpsjIcT5
# eGziWBcGNiuREgPMpNnyLbr5lJ1A7RhF8c6KXGs+qwPTcBgqCmrgX0fR1WMKMvKv
# 1zYfKnBa5UJZCHFLV7p+g4HwITz0HMHFuZCTDohFk4bpsSCZvpjLxZWkXWLWoGMI
# IL11EHd9PfNFuZ+Xn8tXgG8zqQTPd6RiHFl+MYIWPDCCFjgCAQEwgZwwgYQxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLjAsBgNVBAMTJU1pY3Jv
# c29mdCBXaW5kb3dzIFByb2R1Y3Rpb24gUENBIDIwMTECEzMAAAHDE6CFw1bimdcA
# AAAAAcMwDQYJYIZIAWUDBAIBBQCggcYwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# ILgEMa6Q6/kaTdXPWq2hZYIYEb5pku3CGc5DYOhxIACcMFoGCisGAQQBgjcCAQwx
# TDBKoCSAIgBNAGkAYwByAG8AcwBvAGYAdAAgAFcAaQBuAGQAbwB3AHOhIoAgaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3dpbmRvd3MwDQYJKoZIhvcNAQEBBQAEggEA
# P5Y4VTHVAyqJizlfJIsUr+oMuUDzyJGQKFAbJHvauA7ZmxdkuDi9JTNJ3k1P0W5g
# RVVjrE58iihw1iyEFOGFnRjX6uwEvx06tq+45Fvyr249CeQDJYCJ53qJ+UCFfR3X
# 5882jlyh6uRw1wlFLfJHZYZ+t+3s7RQnawmO0jz6MkNx3dg+BP6Rt6tkmCDwZgWt
# ZSsqRncNXZ39vPKn42ie7JkTA1Utx57iFObYPMEI7K9zrYFw2pSm2AbJLW7yqdfE
# zvofSJouWcjrtUNhVcgbOdgGvy3Z5d0YcsTHDupDwoKpnvOA6Z04A0RQWOfj3Bmy
# ZHCXec68EwCjJjz5rrmkDaGCE6cwghOjBgorBgEEAYI3AwMBMYITkzCCE48GCSqG
# SIb3DQEHAqCCE4AwghN8AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFUBgsqhkiG9w0B
# CRABBKCCAUMEggE/MIIBOwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCBSjLxo9Err6/OpA84wKLyDshTG69Rn/9cdX9tRv/nFtAIGW/xP8lGzGBMyMDE4
# MTEyOTA1NDU1NS4wNjFaMAcCAQGAAgPnoIHQpIHNMIHKMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4NDNELTM3RjYt
# RjEwNDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDxMw
# ggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3Nv
# ZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2
# NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6
# f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458
# YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJY
# R4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9L
# ZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioK
# MfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8i
# TQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyK
# MZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjR
# PZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNy
# bDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGg
# BgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBA
# BggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABh
# AHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4Fx
# Az2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcI
# K1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/
# HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QTh
# cJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXsh
# bcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXl
# ZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnf
# XXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvs
# xsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch
# 98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu
# 3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8J
# JxzVs341Hgi62jbb01+P3nSISRIwggTxMIID2aADAgECAhMzAAAA51DpJZvP5ZXE
# AAAAAADnMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMB4XDTE4MDgyMzIwMjcxMVoXDTE5MTEyMzIwMjcxMVowgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjg0M0Qt
# MzdGNi1GMTA0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmElDnYi4fJC6dzf2XBFX
# wyMODlSiqmQu2Rru0qr3JSNpg8ADBdTOKHdjSyfCL9jtAr+ndFVK4mrW2XFvNIy5
# TDjI9hEmwwG8IQI37UDjB3P+vr8GrDr/8XFBljBD9urVQBuHHsAI1yEGaf9jS2Yp
# E8kKh9SZppU0k3VjrrvM57re2pMqAKnOfbdf7E/fM0yUdJYh2RvV41mgcJTwfWKb
# TEHSpwq48s5B4ZPXtBvpma0lXSHVOw5c4WlXCkfQ5BVJ7qdeUBNpv2piWIg6Nwbj
# Rixn75lE0obz1GY7PbKWw1UtF8RbL+7A4JQ+O5I3EV8FHyyb0D6Nhcb3j36CvIjr
# GQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFIE8VOScP7Uf4MEPc6tSGwsGT3CHMB8G
# A1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeG
# RWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUH
# MAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3Rh
# UENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwDQYJKoZIhvcNAQELBQADggEBAA6kCcfcSYfifKW71l9H6E0baCa87Ijp
# fLpsU25I749+ZcDo6RwSene7ATXgW/Rf8JoV1EUUaAUOSXlIDOJFYpI9/mKFCTRs
# qR96pXTJBs7a/Yu8zDCVDsdspZ+e/tEat0ynqgv3Dd5/05bbipQnpUveb0NLmH6J
# xT51VtLfmT0G42La5Kr+BRr1c1+AjOvAqh4ZJZo1dT4l/cmFA6FbqSJHy5HpPIDM
# 3OR2lu5RMuWs2sOuaJTGB8ZUV+iXE794w4CiyggIvAYm2yt1BAYEBJ6EivGatXkX
# M7/FC+ZX1A9S07fl4sqk0pRT011dPjJ7tLg+JRwvMb9FU+IUAdxugo6hggOlMIIC
# jQIBATCB+qGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQG
# A1UECxMdVGhhbGVzIFRTUyBFU046ODQzRC0zN0Y2LUYxMDQxJTAjBgNVBAMTHE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUABWRE
# DLAkWwIb/FKF5bQG2rn0EA6ggdowgdekgdQwgdExCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9w
# ZXJhdGlvbnMxJzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjoyNjY1LTRDM0YtQzVE
# RTErMCkGA1UEAxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1hc3RlciBDbG9jazAN
# BgkqhkiG9w0BAQUFAAIFAN+phawwIhgPMjAxODExMjgyMTIyNTJaGA8yMDE4MTEy
# OTIxMjI1MlowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA36mFrAIBADAHAgEAAgIN
# VjAHAgEAAgIaczAKAgUA36rXLAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEE
# AYRZCgMBoAowCAIBAAIDHoCYoQowCAIBAAIDHoSAMA0GCSqGSIb3DQEBBQUAA4IB
# AQDDToD7utilRRvsFtyk8igl/RFK7oNSIZMmVcu+rdBtzJRGBoAhBtTWoR7cXQ48
# MmznG2P37eiseXuxwPj4fD1WGHETShSupZtD7gvpRUJDqHGf6QimCJxDy9sy0Sgp
# /l7jKpcvI1t86XGjratODMGT7vMe790lk5wL3ri3Sgen8y8sUIVcwJ346btjL6D8
# vgxzfM05kumZj9nRPPN9opbCBnOCkSfQCp7HNN3Yl725toTKyY60ieQThEEO6yqR
# MrijRwF5jWZo1KyKUbPfeDUWfFFk4JzTnNgxeI1LUZ8rIUVl8oMdt8BxSsecp4GW
# n0zuSmNLFWp0TdCCMFsqxuDNMYIC9TCCAvECAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAADnUOklm8/llcQAAAAAAOcwDQYJYIZIAWUDBAIB
# BQCgggEyMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQgihn26lmMCtO0zUhcPv1Zx1B6QqTMPF38PjZLv/Nuji0wgeIGCyqGSIb3DQEJ
# EAIMMYHSMIHPMIHMMIGxBBQFZEQMsCRbAhv8UoXltAbaufQQDjCBmDCBgKR+MHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA51DpJZvP5ZXEAAAAAADn
# MBYEFBBCli5SQENd+IgcZLpZ8nEX6soeMA0GCSqGSIb3DQEBCwUABIIBAEzGBn5/
# q2Jdaq2hdVfIUTAQyzfqpxaRGwB/49hrQulD1YtYRVIdlBBLYLdWIH99xCEmofPk
# NXWx4m6Hw8D/Rnd7DtS4sD82y4sYru8lRvb6imdI7WGwbAGaclTIDthxex3gR1zS
# MAViFSMLxOZH5s6Ve4dzgPIp/e728L7y7AsySSkQ1UzYWoRzynuQt3p3VrVkt1hz
# GcMMjTZxGPVYXzyROAof/CW+y+uvQni2n9mp0WbVad7dPVdG5XMfUpy5yYzT0kGy
# IqGdApnHqVaoV7kXcHmFJflJwatmJQhK911l/5lw14jLXN8I4+OGY4db73YWjHEv
# yyIJrMsP6KMfqS8=
# SIG # End signature block
